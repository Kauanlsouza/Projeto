"""Configurações centralizadas da aplicação.

Este módulo concentra caminhos, valores padrão e leitura do arquivo ``.env``.
Manter essa responsabilidade fora do servidor deixa o ``app.py`` focado nas
rotas HTTP e facilita alterar o ambiente de execução sem editar código.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
INDEX_FILE = BASE_DIR / "index.html"
LOGIN_FILE = BASE_DIR / "login.html"
FAVICON_FILE = BASE_DIR / "static" / "favicon.jpg"
STATIC_DIR = BASE_DIR / "static"
CONFIG_FILE = BASE_DIR / "configuracoes.json"
BACKUP_DIR = BASE_DIR / "backups"
LOCK_FILE = BASE_DIR / ".app.lock"

PAGE_FILES = {
    "inicio": INDEX_FILE,
    "movimentacoes": BASE_DIR / "movimentacoes.html",
    "consulta": BASE_DIR / "consulta.html",
    "disponibilidade": BASE_DIR / "disponibilidade.html",
    "historico": BASE_DIR / "historico.html",
    "configuracoes": BASE_DIR / "configuracoes.html",
}

PAGE_ROUTES = {
    "/": {"page": "inicio", "title": "Sistema de Armarios"},
    "/index.html": {"page": "inicio", "title": "Sistema de Armarios"},
    "/movimentacoes.html": {"page": "movimentacoes", "title": "Movimentacoes | Sistema de Armarios"},
    "/consulta.html": {"page": "consulta", "title": "Consulta | Sistema de Armarios"},
    "/disponibilidade.html": {"page": "disponibilidade", "title": "Disponibilidade | Sistema de Armarios"},
    "/historico.html": {"page": "historico", "title": "Historico | Sistema de Armarios"},
    "/configuracoes.html": {"page": "configuracoes", "title": "Configuracoes | Sistema de Armarios"},
}

CONFIGURACOES_PADRAO = {
    "email_assunto": "Devolucao em atraso - {armario}",
    "email_corpo": (
        "Ola {nome},\n\n"
        "identificamos que o {armario} esta com devolucao prevista para {prazo}.\n"
        "Localizacao: {localizacao}.\n\n"
        "Pedimos a regularizacao o quanto antes.\n\n"
        "Equipe de armarios"
    ),
}


def carregar_dotenv(caminho: Path) -> None:
    """Lê variáveis de um arquivo .env sem sobrescrever o ambiente atual."""
    if not caminho.is_file():
        return

    for linha in caminho.read_text(encoding="utf-8").splitlines():
        conteudo = linha.strip()
        if not conteudo or conteudo.startswith("#") or "=" not in conteudo:
            continue

        chave, valor = conteudo.split("=", 1)
        chave = chave.strip()
        valor = valor.strip().strip('"').strip("'")
        if chave and chave not in os.environ:
            os.environ[chave] = valor


@dataclass(frozen=True)
class AppSettings:
    """Parâmetros de execução carregados uma única vez ao iniciar o sistema."""

    host: str
    port: int


def carregar_settings() -> AppSettings:
    carregar_dotenv(BASE_DIR / ".env")
    host = str(os.getenv("APP_HOST", "0.0.0.0")).strip() or "0.0.0.0"

    try:
        port = int(str(os.getenv("APP_PORT", "5000")).strip())
    except ValueError as exc:
        raise RuntimeError("APP_PORT deve ser um numero inteiro valido.") from exc

    if not 1 <= port <= 65535:
        raise RuntimeError("APP_PORT deve estar entre 1 e 65535.")

    return AppSettings(host=host, port=port)


SETTINGS = carregar_settings()
