"""Testes automatizados do Sistema de Armários."""
