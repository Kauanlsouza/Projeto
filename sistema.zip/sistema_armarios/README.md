# Sistema de Armários Escolares

Aplicação web para gerenciar empréstimos de armários em ambiente escolar. O projeto foi pensado para resolver um processo cotidiano: registrar retiradas e devoluções, acompanhar prazos e manter uma trilha de auditoria clara para a equipe responsável.

## Sobre o projeto

O sistema atende funcionários que administram armários convencionais e grandes. Ele permite consultar disponibilidade, registrar participantes, definir prazos de devolução e acompanhar empréstimos atrasados, tudo em uma interface acessível pelo navegador na rede local.

Mais do que uma tela de cadastro, o projeto busca aplicar práticas de desenvolvimento presentes em sistemas reais: autenticação, níveis de acesso, validação no servidor, persistência de dados, exportação, backups e testes automatizados.

## Principais recursos

- Login de funcionários com senha protegida por hash PBKDF2.
- Perfis de **operador** e **administrador**, com permissões diferentes.
- Cadastro de usuários com confirmação de senha e visualização temporária da senha digitada.
- Empréstimo, devolução, edição e manutenção de armários.
- Validação da capacidade de participantes de acordo com o tamanho do armário.
- Consulta por número do armário ou prontuário.
- Painel com disponibilidade, vencimentos e empréstimos atrasados.
- Histórico com filtros, ordenação, impressão e exportação para CSV.
- Registro de auditoria das operações administrativas e operacionais.
- Cobrança de devolução por e-mail via SMTP.
- Criação de backup e anonimização de dados pessoais de registros antigos.
- Interface responsiva, com tema claro/escuro e suporte à rede local.

## Tecnologias

| Camada | Tecnologias |
| --- | --- |
| Frontend | HTML, CSS e JavaScript puro |
| Backend | Python e servidor HTTP da biblioteca padrão |
| Banco de dados | SQLite |
| Segurança | PBKDF2, cookies `HttpOnly`, validação de dados e controle de sessão |
| Qualidade | Testes automatizados com `unittest` |

O projeto não depende de bibliotecas externas para funcionar, facilitando a instalação em computadores da escola.

## Arquitetura

```text
sistema_armarios/
├── app.py              # Servidor HTTP, rotas, sessão e camada de apresentação
├── settings.py         # Configurações, caminhos do projeto e leitura do .env
├── database.py         # Regras de persistência, migrações e SQLite
├── static/
│   ├── css/app.css     # Estilos da interface
│   └── js/app.js       # Comportamentos do frontend
├── scripts/            # Utilitários, incluindo geração de dados fictícios
├── tests/              # Testes do backend e banco de dados
└── .env.example        # Modelo de configuração local
```

Essa divisão deixa responsabilidades mais claras: `settings.py` trata ambiente e configuração, `database.py` concentra o acesso aos dados e `app.py` atende as requisições do navegador.

## Como executar

### Pré-requisitos

- Python 3.10 ou superior.
- Navegador moderno.

### Instalação

```bash
git clone <URL_DO_REPOSITORIO>
cd sistema_armarios
copy .env.example .env
python app.py
```

Abra [http://localhost:5000](http://localhost:5000). No primeiro acesso, crie a conta administradora na própria tela de login.

No Windows, também é possível iniciar com dois cliques em `iniciar_sistema.bat`.

## Configuração

Use o arquivo `.env.example` como modelo para criar o arquivo `.env`. Nele você pode configurar:

- Endereço e porta da aplicação (`APP_HOST` e `APP_PORT`);
- Credenciais do primeiro administrador;
- Senha secreta para cadastro de operadores;
- Dados do serviço de e-mail SMTP.

> Nunca publique o arquivo `.env`, bancos de produção ou informações reais de estudantes. O `.gitignore` já protege esses arquivos novos.

## Uso na rede local

O servidor inicia em `0.0.0.0` por padrão, permitindo o acesso por outros dispositivos da mesma rede. Após iniciar, o terminal exibe os endereços disponíveis.

1. Execute o sistema em uma única máquina da rede.
2. Mantenha essa máquina ligada durante o uso.
3. Abra, nos outros computadores, o endereço exibido como `Na rede local`.

Se necessário, libere o Python no perfil de rede privada do Firewall do Windows. A aplicação não deve ser exposta diretamente à internet.

## Dados demonstrativos

Para gerar um banco independente, contendo somente pessoas e e-mails fictícios:

```bash
python scripts/criar_dados_demo.py --output dados_demo/armarios_demo.db
```

O script não substitui o banco principal. Para demonstrar o projeto, use uma cópia da pasta e substitua o banco dessa cópia pelo arquivo gerado. Credenciais de demonstração: `demo` / `senha-demo-segura`.

## Testes

Execute a suíte automatizada com:

```bash
python -m unittest discover -s tests -v
```

Os testes usam um banco temporário e não devem alterar os registros reais. A suíte cobre regras de empréstimo, devolução, permissões, backups, autenticação e respostas do servidor.

## Segurança e privacidade

- Senhas não são armazenadas em texto puro.
- As sessões usam cookies `HttpOnly` e expiram automaticamente.
- Rotas administrativas exigem autenticação e perfil de administrador.
- Dados exportados para CSV são protegidos contra interpretação de fórmulas em planilhas.
- Ações sensíveis são registradas na auditoria.
- Há recursos para backup e anonimização de dados pessoais.

## Ideias para evolução

- Publicar uma demonstração online com dados fictícios.
- Adicionar documentação da API e capturas de tela ao repositório.
- Criar pipeline de integração contínua para executar testes a cada alteração.
- Incluir indicadores de uso no painel administrativo.
- Migrar a camada HTTP para um framework, como FastAPI, caso o projeto cresça e precise de uma API pública.

## Contexto para portfólio

Este projeto demonstra desenvolvimento de ponta a ponta: modelagem de dados, regras de negócio, autenticação, interface web, testes e preocupações de segurança. Ele foi construído com foco em uma necessidade real de gestão escolar e em uma experiência simples para os funcionários que utilizam o sistema.
