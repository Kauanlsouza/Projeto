export const API = "";

export const TIPOS_ARMARIO = Object.freeze({
    livro: Object.freeze({
        rotulo: "Armario de livro",
        localizacao: "Andar de baixo, ao lado da biblioteca",
    }),
    convencional: Object.freeze({
        rotulo: "Armario convencional",
        localizacao: "Andar de cima",
    }),
});
