import { buscarJson, enviarCobrancaEmail } from "./api.js";
import { API, TIPOS_ARMARIO } from "./config.js";

let listaArmariosVisivel = true;
let armariosCache = [];
let filtroRapido = "todos";
let debounceHistorico;
let temaAtual = "claro";
let areaAtual = "painel";

const el = (id) => document.getElementById(id);

function focarCampo(id) {
    if (!id) return;
    const campo = el(id);
    if (!campo) return;
    setTimeout(() => campo.focus(), 60);
}

function garantirMapaVisivel() {
    const wrapper = el("lista-wrapper");
    const botao = el("botao-lista");
    const cardMapa = el("card-mapa-visual");
    if (!wrapper || !botao || !cardMapa) return;
    cardMapa.classList.remove("oculto");
    wrapper.classList.remove("oculto");
    botao.textContent = "Ocultar mapa";
    listaArmariosVisivel = true;
}

function irParaArea(area, focoId = "") {
    const areasValidas = ["painel", "emprestar", "devolver", "consulta", "mapa", "historico"];
    areaAtual = areasValidas.includes(area) ? area : "painel";

    document.querySelectorAll(".guia-botao").forEach((botao) => {
        botao.classList.toggle("ativa", botao.dataset.area === areaAtual);
    });

    document.querySelectorAll(".painel-area").forEach((secao) => {
        secao.classList.toggle("ativa", secao.dataset.area === areaAtual);
    });

    try {
        localStorage.setItem("area_armarios", areaAtual);
    } catch (erro) {
    }

    if (areaAtual === "mapa") {
        garantirMapaVisivel();
    }

    focarCampo(focoId);
}

function abrirMapaComFiltro(filtro = "todos") {
    irParaArea("mapa", "filtro-armario");
    el("filtro-armario").value = "";
    definirFiltroRapido(filtro);
}

function escaparHtml(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[char]));
}

function textoOuPadrao(valor, fallback = "-") {
    const texto = String(valor ?? "").trim();
    return texto ? escaparHtml(texto) : escaparHtml(fallback);
}

function exibirMensagem(texto, tipo = "sucesso", toast = false) {
    el("mensagem").textContent = texto;
    el("mensagem").className = `mensagem ${tipo}`;
    if (toast) mostrarToast(texto, tipo);
}

function mostrarToast(texto, tipo = "sucesso") {
    const stack = el("toast-stack");
    const item = document.createElement("div");
    item.className = `toast ${tipo}`;
    item.textContent = texto;
    stack.appendChild(item);
    setTimeout(() => item.remove(), 3600);
}

function aplicarTemaSeguro(tema) {
    temaAtual = tema === "escuro" ? "escuro" : "claro";
    document.body.classList.toggle("tema-escuro", temaAtual === "escuro");
    el("tema-icone").innerHTML = temaAtual === "escuro" ? "&#9728;" : "&#9790;";
    el("tema-texto").textContent = temaAtual === "escuro" ? "Modo claro" : "Modo escuro";
    try {
        localStorage.setItem("tema_armarios", temaAtual);
    } catch (erro) {
    }
}

function alternarTema() {
    aplicarTemaSeguro(temaAtual === "escuro" ? "claro" : "escuro");
}

function formatarDataParaBR(valor) {
    if (!valor) return "";
    if (valor.includes("/")) return valor;
    const [ano, mes, dia] = valor.split("-");
    return `${dia}/${mes}/${ano}`;
}

function formatarDataDeInputHoje() {
    const hoje = new Date();
    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, "0");
    const dia = String(hoje.getDate()).padStart(2, "0");
    return `${ano}-${mes}-${dia}`;
}

function rotuloTipo(tipo) {
    return TIPOS_ARMARIO[tipo]?.rotulo || "Armario";
}

function limiteNumero(tipo) {
    return tipo === "livro" ? 32 : 88;
}

function rotuloTamanho(tamanho) {
    return tamanho === "grande" ? "Grande" : "Padrao";
}

function obterLocalizacao(tipo, fallback = "") {
    return fallback || TIPOS_ARMARIO[tipo]?.localizacao || "-";
}

function descricaoFaixaNumeracao(tipo) {
    const maximo = String(limiteNumero(tipo)).padStart(2, "0");
    return `${rotuloTipo(tipo)}: use a numeracao de 01 a ${maximo}.`;
}

function obterIdentificacao(item) {
    return item.identificacao || `${rotuloTipo(item.tipo)} ${item.numero}`;
}

function rotuloStatus(status) {
    if (status === "livre") return "Livre";
    if (status === "parcial") return "Parcial";
    return "Lotado";
}

function rotuloStatusHistorico(status) {
    return status === "ativo" ? "Ativo" : "Devolvido";
}

function emailValido(valor) {
    return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(valor || "").trim());
}

function formatarNumeroArmario(numero) {
    const valor = Number(numero);
    return Number.isFinite(valor) && valor > 0 ? String(valor).padStart(2, "0") : String(numero ?? "-");
}

function rotuloNumeroCurto(item) {
    return `Armario ${formatarNumeroArmario(item.numero)}`;
}

function ocupantesDoArmario(item) {
    return Array.isArray(item?.ocupantes) ? item.ocupantes : [];
}

function resumoOcupacao(item) {
    return `${Number(item?.ocupacao_atual || 0)}/${Number(item?.capacidade || 0)}`;
}

function textoVagas(item) {
    const vagas = Number(item?.vagas_disponiveis || 0);
    if (vagas <= 0) return "Sem vagas";
    return vagas === 1 ? "1 vaga disponivel" : `${vagas} vagas disponiveis`;
}

function classePreviewStatus(item) {
    if (armarioTemVencimento(item, "atrasado")) return "atrasado";
    if (item.status === "parcial") return "parcial";
    if (item.status === "ocupado") return "ocupado";
    return "livre";
}

function renderizarIconeTipo(tipo) {
    const titulo = rotuloTipo(tipo);
    const svg = tipo === "livro"
        ? `
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 5.5A2.5 2.5 0 0 1 8.5 3H19v16H8.5A2.5 2.5 0 0 0 6 21.5z" />
                <path d="M6 5.5v16" />
                <path d="M9.5 7H16" />
                <path d="M9.5 10H16" />
            </svg>
        `
        : `
            <svg viewBox="0 0 24 24" aria-hidden="true">
                <rect x="5" y="4" width="14" height="16" rx="2" />
                <path d="M12 4v16" />
                <path d="M8.5 9h1" />
                <path d="M14.5 9h1" />
            </svg>
        `;
    return `<span class="tipo-icone tipo-${tipo}" role="img" aria-label="${escaparHtml(titulo)}" title="${escaparHtml(titulo)}">${svg}</span>`;
}

function obterRotuloVencimento(vencimento) {
    if (vencimento === "atrasado") return "Devolucao atrasada";
    if (vencimento === "vence_hoje") return "Vence hoje";
    if (vencimento === "vence_amanha") return "Vence amanha";
    return "No prazo";
}

function normalizarVencimento(item) {
    if (item && item.vencimento) return item.vencimento;
    if (item && item.atrasado) return "atrasado";
    if (item && item.status === "livre") return "sem_prazo";
    return "no_prazo";
}

function obterHojeLocal() {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    return hoje;
}

function parseDataBr(valor) {
    const texto = String(valor || "").trim();
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(texto)) return null;
    const [dia, mes, ano] = texto.split("/").map(Number);
    const data = new Date(ano, mes - 1, dia);
    if (
        data.getFullYear() !== ano ||
        data.getMonth() !== mes - 1 ||
        data.getDate() !== dia
    ) return null;
    data.setHours(0, 0, 0, 0);
    return data;
}

function calcularDiasAtraso(dataPrevista) {
    const data = parseDataBr(dataPrevista);
    if (!data) return 0;
    const diferenca = Math.floor((obterHojeLocal() - data) / 86400000);
    return Math.max(0, diferenca);
}

function classeUrgenciaAtraso(item) {
    const dias = calcularDiasAtraso(item?.data_prevista);
    if (dias >= 7) return "atraso-critico";
    if (dias >= 3) return "atraso-alto";
    return "atraso-recente";
}

function rotuloUrgenciaAtraso(item) {
    const classe = classeUrgenciaAtraso(item);
    if (classe === "atraso-critico") return "Critico";
    if (classe === "atraso-alto") return "Atencao";
    return "Recente";
}

function detalheUrgenciaAtraso(item) {
    const dias = calcularDiasAtraso(item?.data_prevista);
    if (dias === 1) return "1 dia de atraso";
    return `${Math.max(dias, 1)} dias de atraso`;
}

function contarUrgenciasAtraso(lista) {
    return lista.reduce((acc, item) => {
        const classe = classeUrgenciaAtraso(item);
        acc[classe] += 1;
        return acc;
    }, { "atraso-recente": 0, "atraso-alto": 0, "atraso-critico": 0 });
}

function buscarArmarioNoCache(tipo, numero) {
    const numeroArmario = Number(numero);
    if (!Number.isFinite(numeroArmario)) return null;
    return armariosCache.find((item) => item.tipo === tipo && Number(item.numero) === numeroArmario) || null;
}

function armarioTemVencimento(item, alvo) {
    return ocupantesDoArmario(item).some((ocupante) => normalizarVencimento(ocupante) === alvo);
}

function classeVisualArmario(item) {
    if (armarioTemVencimento(item, "atrasado")) return "atrasado";
    if (armarioTemVencimento(item, "vence_hoje")) return "vence-hoje";
    if (armarioTemVencimento(item, "vence_amanha")) return "vence-amanha";
    if (item.status === "parcial") return "parcial";
    if (item.status === "ocupado") return "ocupado";
    return "livre";
}

function pluralizar(valor, singular, plural = "") {
    const quantidade = Number(valor) || 0;
    if (!plural) plural = `${singular}s`;
    return quantidade === 1 ? singular : plural;
}

function textoCapacidade(item) {
    const capacidade = Number(item?.capacidade || 0);
    return `${capacidade} ${pluralizar(capacidade, "pessoa")}`;
}

function renderizarResumoOcupacao(item) {
    return `
        <div class="preview-resumo-ocupacao">
            <span class="mini-tag">Ocupacao ${escaparHtml(resumoOcupacao(item))}</span>
            <span class="mini-tag">${escaparHtml(textoVagas(item))}</span>
            <span class="mini-tag">Capacidade ${escaparHtml(textoCapacidade(item))}</span>
            <span class="mini-tag">Tamanho ${escaparHtml(rotuloTamanho(item.tamanho))}</span>
        </div>
    `;
}

function renderizarBotaoDevolucaoOcupante(item, ocupante) {
    return `
        <button
            type="button"
            class="botao-secundario"
            data-acao="devolver-ocupante"
            data-tipo="${escaparHtml(item.tipo)}"
            data-numero="${escaparHtml(String(item.numero))}"
            data-prontuario="${escaparHtml(ocupante.prontuario || "")}"
        >
            Devolver ocupante
        </button>
    `;
}

function renderizarCardOcupante(item, ocupante, opcoes = {}) {
    const vencimento = normalizarVencimento(ocupante);
    const classeVencimento = vencimento.replaceAll("_", "-");
    const destaqueClasse = opcoes.destaque ? " ocupante-destaque" : "";
    const acoes = [];

    if (vencimento === "atrasado") {
        acoes.push(renderizarAcaoCobranca({ ...item, ...ocupante }));
    }
    if (opcoes.comAcaoDevolucao) {
        acoes.push(renderizarBotaoDevolucaoOcupante(item, ocupante));
    }

    return `
        <article class="ocupante-card${destaqueClasse}">
            <div class="ocupante-topo">
                <div>
                    <strong>${textoOuPadrao(ocupante.nome, "Aluno nao informado")}</strong>
                    <span>Prontuario ${textoOuPadrao(ocupante.prontuario)}</span>
                </div>
                <span class="armario-alerta ${classeVencimento}">${escaparHtml(obterRotuloVencimento(vencimento))}</span>
            </div>
            <div class="ocupante-meta">
                <div class="ocupante-meta-item">
                    <span>Email</span>
                    <strong>${textoOuPadrao(ocupante.email, "Nao informado")}</strong>
                </div>
                <div class="ocupante-meta-item">
                    <span>Curso</span>
                    <strong>${textoOuPadrao(ocupante.curso, "Nao informado")}</strong>
                </div>
                <div class="ocupante-meta-item">
                    <span>Retirada</span>
                    <strong>${textoOuPadrao(ocupante.data_retirada)}</strong>
                </div>
                <div class="ocupante-meta-item">
                    <span>Prazo</span>
                    <strong>${textoOuPadrao(ocupante.data_prevista)}</strong>
                </div>
            </div>
            ${acoes.filter(Boolean).length ? `<div class="lista-registro-acoes">${acoes.filter(Boolean).join("")}</div>` : ""}
        </article>
    `;
}

function atualizarDicasMovimentacao() {
    const dicaEmprestimo = el("dica-tipo-armario");
    const dicaDevolucao = el("dica-tipo-dev");
    if (dicaEmprestimo) dicaEmprestimo.textContent = descricaoFaixaNumeracao(el("tipo-armario").value);
    if (dicaDevolucao) dicaDevolucao.textContent = descricaoFaixaNumeracao(el("tipo-dev").value);
    atualizarPreviewEmprestimo();
}

function renderizarPreviewVazio(id, titulo, descricao) {
    const destino = el(id);
    destino.className = "preview-devolucao preview-vazio";
    destino.innerHTML = `
        <strong>${escaparHtml(titulo)}</strong>
        <p>${escaparHtml(descricao)}</p>
    `;
}

function renderizarPreviewEmprestimoVazio(titulo, descricao) {
    renderizarPreviewVazio("preview-emprestimo", titulo, descricao);
}

function renderizarPreviewDevolucaoVazio(titulo, descricao) {
    renderizarPreviewVazio("preview-devolucao", titulo, descricao);
}

function renderizarPreviewEmprestimoItem(item) {
    const ocupantes = ocupantesDoArmario(item);
    const statusClasse = classePreviewStatus(item);
    const statusTexto = item.vagas_disponiveis > 0 ? textoVagas(item) : "Sem vagas disponiveis";
    el("preview-emprestimo").className = "preview-devolucao";
    el("preview-emprestimo").innerHTML = `
        <div class="preview-topo">
            <div>
                <div class="preview-titulo">${escaparHtml(obterIdentificacao(item))}</div>
                <div class="preview-subtitulo">${escaparHtml(obterLocalizacao(item.tipo, item.localizacao))}</div>
            </div>
            <span class="preview-alerta ${statusClasse}">${escaparHtml(statusTexto)}</span>
        </div>
        ${renderizarResumoOcupacao(item)}
        ${
            ocupantes.length
                ? `<div class="preview-lista-ocupantes">${ocupantes.map((ocupante) => renderizarCardOcupante(item, ocupante)).join("")}</div>`
                : `
                    <div class="armario-vazio">
                        <strong>Armario pronto para novo emprestimo</strong>
                        <span class="armario-meta">Nenhum aluno usando este armario no momento.</span>
                    </div>
                `
        }
    `;
}

function renderizarPreviewDevolucaoItem(item) {
    const ocupantes = ocupantesDoArmario(item);
    const statusClasse = classePreviewStatus(item);
    el("preview-devolucao").className = "preview-devolucao";
    el("preview-devolucao").innerHTML = `
        <div class="preview-topo">
            <div>
                <div class="preview-titulo">${escaparHtml(obterIdentificacao(item))}</div>
                <div class="preview-subtitulo">${escaparHtml(obterLocalizacao(item.tipo, item.localizacao))}</div>
            </div>
            <span class="preview-alerta ${statusClasse}">${escaparHtml(rotuloStatus(item.status))}</span>
        </div>
        ${renderizarResumoOcupacao(item)}
        ${
            ocupantes.length
                ? `<div class="preview-lista-ocupantes">${ocupantes.map((ocupante) => renderizarCardOcupante(item, ocupante, { comAcaoDevolucao: true })).join("")}</div>`
                : `
                    <div class="armario-vazio">
                        <strong>Armario livre</strong>
                        <span class="armario-meta">Nao ha ocupantes ativos para remover neste armario.</span>
                    </div>
                `
        }
    `;
}

function atualizarPreviewEmprestimo() {
    const tipo = el("tipo-armario").value.trim();
    const numeroTexto = el("num").value.trim();
    if (!numeroTexto) {
        renderizarPreviewEmprestimoVazio(
            "Aguardando escolha do armario",
            "Ao informar tipo e numero, a tela mostra quantas vagas ainda restam e quem ja ocupa o armario."
        );
        return;
    }

    const numero = Number(numeroTexto);
    if (!Number.isFinite(numero) || numero < 1) {
        renderizarPreviewEmprestimoVazio("Numero invalido", "Digite um numero valido para conferir a ocupacao do armario.");
        return;
    }

    if (numero > limiteNumero(tipo)) {
        renderizarPreviewEmprestimoVazio("Fora da faixa do tipo", descricaoFaixaNumeracao(tipo));
        return;
    }

    const item = buscarArmarioNoCache(tipo, numero);
    if (!item) {
        renderizarPreviewEmprestimoVazio("Armario nao encontrado", "Atualize o painel se o numero acabou de ser criado ou alterado.");
        return;
    }

    renderizarPreviewEmprestimoItem(item);
}

function atualizarPreviewDevolucao() {
    const tipo = el("tipo-dev").value.trim();
    const numeroTexto = el("num_dev").value.trim();
    if (!numeroTexto) {
        renderizarPreviewDevolucaoVazio(
            "Aguardando numero do armario",
            "Ao informar o tipo e o numero, a previa mostra todos os ocupantes com email, prazo e botao de devolucao individual."
        );
        return;
    }

    const numero = Number(numeroTexto);
    if (!Number.isFinite(numero) || numero < 1) {
        renderizarPreviewDevolucaoVazio("Numero invalido", "Digite um numero valido para visualizar a previa da devolucao.");
        return;
    }

    if (numero > limiteNumero(tipo)) {
        renderizarPreviewDevolucaoVazio("Fora da faixa do tipo", descricaoFaixaNumeracao(tipo));
        return;
    }

    const item = buscarArmarioNoCache(tipo, numero);
    if (!item) {
        renderizarPreviewDevolucaoVazio("Armario nao encontrado", "Atualize o painel se o numero acabou de ser criado ou alterado.");
        return;
    }

    renderizarPreviewDevolucaoItem(item);
}

function limparFormularioEmprestimo() {
    el("tipo-armario").value = "livro";
    el("num").value = "";
    el("nome").value = "";
    el("email").value = "";
    el("pront").value = "";
    el("curso").value = "";
    el("data_prev").value = formatarDataDeInputHoje();
    atualizarDicasMovimentacao();
    atualizarPreviewEmprestimo();
}

function setBotoesDesabilitados(ids, desabilitado, texto) {
    ids.forEach((id) => {
        const botao = el(id);
        if (!botao) return;
        if (!botao.dataset.labelOriginal) botao.dataset.labelOriginal = botao.textContent;
        botao.disabled = desabilitado;
        botao.textContent = desabilitado ? texto : botao.dataset.labelOriginal;
    });
}

function obterParametrosHistorico() {
    const params = new URLSearchParams();
    [
        ["nome", "hist-nome"],
        ["prontuario", "hist-prontuario"],
        ["tipo_armario", "hist-tipo"],
        ["status", "hist-status"],
        ["data_inicio", "hist-data-inicio"],
        ["data_fim", "hist-data-fim"]
    ].forEach(([chave, id]) => {
        const valor = el(id).value.trim();
        if (valor) params.append(chave, valor);
    });
    return params;
}

function agruparPorTipo(lista) {
    return lista.reduce((acc, item) => {
        const tipo = item.tipo || "convencional";
        if (!acc[tipo]) acc[tipo] = [];
        acc[tipo].push(item);
        return acc;
    }, {});
}

function ordenarPorNumero(lista) {
    return [...lista].sort((a, b) => Number(a.numero || 0) - Number(b.numero || 0));
}

function combinaFiltroMapa(item, valor) {
    if (valor === "todos") return true;
    if (valor === "com_vaga") return Number(item.vagas_disponiveis || 0) > 0;
    if (valor === "ocupado") return item.status === "ocupado";
    if (valor === "atrasado" || valor === "vence_hoje" || valor === "vence_amanha") {
        return armarioTemVencimento(item, valor);
    }
    return true;
}

function contarPorFiltro(valor) {
    return armariosCache.filter((item) => combinaFiltroMapa(item, valor)).length;
}

function atualizarContadoresFiltros() {
    ["todos", "com_vaga", "ocupado", "atrasado", "vence_hoje", "vence_amanha"].forEach((filtro) => {
        const alvo = el(`chip-count-${filtro}`);
        if (alvo) alvo.textContent = contarPorFiltro(filtro);
    });
}

function resumoGrupo(lista) {
    const vazios = lista.filter((item) => item.status === "livre").length;
    const parciais = lista.filter((item) => item.status === "parcial").length;
    const lotados = lista.filter((item) => item.status === "ocupado").length;
    const comVaga = lista.filter((item) => Number(item.vagas_disponiveis || 0) > 0).length;
    const atrasados = lista.filter((item) => armarioTemVencimento(item, "atrasado")).length;
    return {
        total: lista.length,
        vazios,
        parciais,
        lotados,
        comVaga,
        atrasados,
        alunos: lista.reduce((acc, item) => acc + Number(item.ocupacao_atual || 0), 0),
        vagas: lista.reduce((acc, item) => acc + Number(item.vagas_disponiveis || 0), 0)
    };
}

function atualizarResumoMapa() {
    const destino = el("resumo-mapa");
    if (!destino) return;
    if (!armariosCache.length) {
        destino.innerHTML = "";
        return;
    }

    const resumo = resumoGrupo(armariosCache);
    destino.innerHTML = `
        <span class="historico-pill"><strong>${resumo.total}</strong> armarios</span>
        <span class="historico-pill"><strong>${resumo.comVaga}</strong> com vaga</span>
        <span class="historico-pill"><strong>${resumo.parciais}</strong> parciais</span>
        <span class="historico-pill"><strong>${resumo.lotados}</strong> lotados</span>
        <span class="historico-pill"><strong>${resumo.alunos}</strong> alunos usando</span>
        <span class="historico-pill"><strong>${resumo.vagas}</strong> vagas livres</span>
    `;
}

function renderizarCampoConsulta(rotulo, valor) {
    return `
        <div class="consulta-campo">
            <span>${escaparHtml(rotulo)}</span>
            <strong>${textoOuPadrao(valor)}</strong>
        </div>
    `;
}

function renderizarChipInfo(rotulo, valor) {
    return `
        <span class="armario-chip">
            <span>${escaparHtml(rotulo)}</span>
            ${textoOuPadrao(valor)}
        </span>
    `;
}

function renderizarResumoAtrasos(lista) {
    const contagens = contarUrgenciasAtraso(lista);
    const configuracoes = [
        { classe: "atraso-recente", rotulo: "1-2 dias" },
        { classe: "atraso-alto", rotulo: "3-6 dias" },
        { classe: "atraso-critico", rotulo: "7+ dias" }
    ];
    return `
        <div class="atrasos-resumo">
            <span class="atrasos-pill"><span>Total</span><strong>${lista.length}</strong></span>
            ${configuracoes.map((item) => `
                <span class="atrasos-pill ${item.classe}">
                    <span>${item.rotulo}</span>
                    <strong>${contagens[item.classe]}</strong>
                </span>
            `).join("")}
        </div>
    `;
}

function renderizarRegistroAtrasado(item) {
    const urgenciaClasse = classeUrgenciaAtraso(item);
    const acaoCobranca = renderizarAcaoCobranca(item);
    return `
        <article class="lista-registro ${urgenciaClasse}">
            <div class="lista-registro-topo">
                <div>
                    <div class="lista-registro-titulo">${textoOuPadrao(item.nome, "Aluno nao informado")}</div>
                    <div class="lista-registro-subtitulo">${escaparHtml(rotuloNumeroCurto(item))} - ${escaparHtml(detalheUrgenciaAtraso(item))}</div>
                </div>
                <span class="tag-urgencia ${urgenciaClasse}">${escaparHtml(rotuloUrgenciaAtraso(item))}</span>
            </div>
            <div class="lista-registro-grade">
                <div class="lista-registro-campo">
                    <span>Email</span>
                    <strong>${textoOuPadrao(item.email, "Nao informado")}</strong>
                </div>
                <div class="lista-registro-campo">
                    <span>Prontuario</span>
                    <strong>${textoOuPadrao(item.prontuario)}</strong>
                </div>
                <div class="lista-registro-campo">
                    <span>Prazo</span>
                    <strong>${textoOuPadrao(item.data_prevista)}</strong>
                </div>
                <div class="lista-registro-campo">
                    <span>Localizacao</span>
                    <strong>${escaparHtml(obterLocalizacao(item.tipo, item.localizacao))}</strong>
                </div>
            </div>
            ${acaoCobranca ? `<div class="lista-registro-acoes">${acaoCobranca}</div>` : ""}
        </article>
    `;
}

function renderizarAcaoCobranca(item) {
    const email = String(item?.email || "").trim();
    const prontuario = String(item?.prontuario || "").trim();
    if (!emailValido(email) || !prontuario) return "";
    return `
        <button
            type="button"
            class="link-cobranca"
            data-acao="cobrar-email"
            data-tipo="${escaparHtml(item.tipo)}"
            data-numero="${escaparHtml(String(item.numero))}"
            data-prontuario="${escaparHtml(prontuario)}"
        >
            Cobrar por email
        </button>
    `;
}

function atualizarIndicadorResumo(nome, valor, total) {
    const quantidade = Number(valor) || 0;
    const base = Number(total) || 0;
    const percentualReal = base > 0 ? Math.round((quantidade / base) * 100) : 0;
    const barra = el(`resumo-barra-${nome}`);
    const percentual = el(`resumo-percentual-${nome}`);
    const totalEl = el(`resumo-status-${nome}`);
    if (totalEl) totalEl.textContent = quantidade;
    if (percentual) percentual.textContent = `${percentualReal}%`;
    if (barra) {
        barra.style.width = `${percentualReal}%`;
        barra.classList.toggle("com-dado", quantidade > 0);
    }
}

async function carregarResumo() {
    try {
        const data = await buscarJson("/resumo");
        const resumo = data.resumo || {};
        el("resumo-livre").textContent = Number(resumo.com_vaga || 0);
        el("resumo-ocupado").textContent = Number(resumo.ocupado || 0);
        el("resumo-atrasado").textContent = Number(resumo.atrasados || 0);
        el("resumo-vazios").textContent = Number(resumo.livre || 0);
        el("resumo-parcial").textContent = Number(resumo.parcial || 0);
        el("resumo-alunos").textContent = Number(resumo.alunos_ativos || 0);
        const totalArmarios =
            (Number(resumo.livre) || 0) +
            (Number(resumo.parcial) || 0) +
            (Number(resumo.ocupado) || 0);
        const capacidadeTotal = Number(resumo.capacidade_total || 0);
        const alunosAtivos = Number(resumo.alunos_ativos || 0);
        el("resumo-total-etiqueta").textContent = `${totalArmarios} armario(s)`;
        el("resumo-status-total").textContent = capacidadeTotal;
        el("resumo-percentual-total").textContent = capacidadeTotal > 0 ? "100%" : "0%";
        const barraTotal = el("resumo-barra-total");
        if (barraTotal) {
            barraTotal.style.width = capacidadeTotal > 0 ? "100%" : "0%";
            barraTotal.classList.toggle("com-dado", capacidadeTotal > 0);
        }
        atualizarIndicadorResumo("livre", resumo.vagas_disponiveis, capacidadeTotal);
        atualizarIndicadorResumo("ocupado", alunosAtivos, capacidadeTotal);
        atualizarIndicadorResumo("atrasado", resumo.atrasados, alunosAtivos || capacidadeTotal);
        el("alerta-atrasos").textContent = Number(resumo.atrasados || 0) > 0
            ? `${resumo.atrasados} pendencia(s) em atraso.`
            : "Nenhum atraso no momento.";
    } catch (erro) {
        exibirMensagem(erro.message, "erro");
    }
}

async function listar() {
    const data = await buscarJson("/armarios");
    armariosCache = ordenarPorNumero(data.armarios);
    atualizarContadoresFiltros();
    atualizarResumoMapa();
    renderizarArmariosFiltrados();
    atualizarPreviewEmprestimo();
    atualizarPreviewDevolucao();
}

function definirFiltroRapido(valor) {
    filtroRapido = valor;
    document.querySelectorAll(".chip").forEach((chip) => {
        chip.classList.toggle("ativo", chip.dataset.filtro === valor);
    });
    renderizarArmariosFiltrados();
}

function filtroRapidoCombina(item) {
    return combinaFiltroMapa(item, filtroRapido);
}

function renderizarGrupoArmarios(tipo, lista) {
    const itens = ordenarPorNumero(lista);
    if (!itens.length) return "";
    const localizacao = obterLocalizacao(tipo, itens[0]?.localizacao);
    const resumo = resumoGrupo(itens);
    return `
        <section class="grupo-armarios">
            <div class="grupo-cabecalho">
                <div class="grupo-titulo">
                    <strong>${escaparHtml(rotuloTipo(tipo))}</strong>
                    <span>${escaparHtml(localizacao)}</span>
                </div>
                <div class="grupo-resumo">
                    <span class="mini-tag">${resumo.total} armario(s)</span>
                    <span class="mini-tag">${resumo.comVaga} com vaga</span>
                    <span class="mini-tag">${resumo.parciais} parciais</span>
                    <span class="mini-tag">${resumo.lotados} lotados</span>
                    ${resumo.atrasados ? `<span class="mini-tag mini-tag--alerta">${resumo.atrasados} atrasados</span>` : ""}
                </div>
            </div>
            <div class="grupo-lista">
                ${itens.map((item) => {
                    const ocupantes = ocupantesDoArmario(item);
                    const classe = classeVisualArmario(item);
                    const detalhes = ocupantes.length
                        ? `
                            ${renderizarResumoOcupacao(item)}
                            <div class="ocupantes-lista">
                                ${ocupantes.map((ocupante) => renderizarCardOcupante(item, ocupante)).join("")}
                            </div>
                        `
                        : `
                            <div class="armario-vazio">
                                <strong>Disponivel agora</strong>
                                <span class="armario-meta">Pronto para novo emprestimo.</span>
                            </div>
                            <div class="armario-secundarios">
                                ${renderizarChipInfo("Capacidade", textoCapacidade(item))}
                                ${renderizarChipInfo("Vagas", textoVagas(item))}
                                ${renderizarChipInfo("Tamanho", rotuloTamanho(item.tamanho))}
                            </div>
                        `;
                    return `
                        <article class="armario-item ${classe}">
                            <div class="armario-topo">
                                <div class="armario-cabeca">
                                    <div class="armario-numero">${escaparHtml(formatarNumeroArmario(item.numero))}</div>
                                    <div class="armario-meta">${escaparHtml(textoVagas(item))}</div>
                                </div>
                                <div class="armario-acoes">
                                    ${renderizarIconeTipo(item.tipo)}
                                    <span class="armario-status status-${item.status}">${rotuloStatus(item.status)}</span>
                                </div>
                            </div>
                            ${detalhes}
                        </article>
                    `;
                }).join("")}
            </div>
        </section>
    `;
}

function renderizarArmariosFiltrados() {
    const destino = el("lista");
    const filtro = el("filtro-armario").value.trim().toLowerCase();
    const armariosFiltrados = armariosCache.filter((item) => {
        const textoOcupantes = ocupantesDoArmario(item).map((ocupante) => [
            ocupante.nome || "",
            ocupante.email || "",
            ocupante.prontuario || "",
            ocupante.curso || "",
            ocupante.data_prevista || ""
        ].join(" ")).join(" ");
        const texto = [
            String(item.numero),
            item.tipo || "",
            rotuloTipo(item.tipo),
            item.status || "",
            item.identificacao || "",
            textoOcupantes,
            item.localizacao || "",
            item.tamanho || "",
            resumoOcupacao(item),
            textoVagas(item)
        ].join(" ").toLowerCase();
        return texto.includes(filtro) && filtroRapidoCombina(item);
    });

    if (!armariosFiltrados.length) {
        destino.innerHTML = '<div class="consulta-card"><p>Nenhum armario corresponde aos filtros atuais.</p></div>';
        return;
    }

    const grupos = agruparPorTipo(armariosFiltrados);
    destino.innerHTML = [
        renderizarGrupoArmarios("livro", grupos.livro || []),
        renderizarGrupoArmarios("convencional", grupos.convencional || [])
    ].join("");
}

async function alternarListaArmarios() {
    const wrapper = el("lista-wrapper");
    const botao = el("botao-lista");
    const cardMapa = el("card-mapa-visual");
    if (!wrapper || !botao || !cardMapa) return;
    if (listaArmariosVisivel) {
        cardMapa.classList.add("oculto");
        wrapper.classList.add("oculto");
        botao.textContent = "Mostrar mapa";
        listaArmariosVisivel = false;
        exibirMensagem("Mapa de armarios ocultado.");
        return;
    }
    try {
        await listar();
        cardMapa.classList.remove("oculto");
        wrapper.classList.remove("oculto");
        botao.textContent = "Ocultar mapa";
        listaArmariosVisivel = true;
        exibirMensagem("Mapa de armarios exibido.");
    } catch (erro) {
        exibirMensagem(erro.message, "erro");
    }
}

async function emprestar() {
    setBotoesDesabilitados(["botao-emprestar"], true, "Enviando...");
    try {
        const data = await buscarJson("/emprestar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                tipo_armario: el("tipo-armario").value.trim(),
                numero: el("num").value.trim(),
                nome: el("nome").value.trim(),
                email: el("email").value.trim().toLowerCase(),
                prontuario: el("pront").value.trim(),
                curso: el("curso").value.trim(),
                data_retirada: formatarDataParaBR(formatarDataDeInputHoje()),
                data_prevista: formatarDataParaBR(el("data_prev").value.trim())
            })
        });
        limparFormularioEmprestimo();
        exibirMensagem(data.mensagem || "Emprestimo realizado com sucesso.", "sucesso", true);
        await atualizarTudo(true);
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    } finally {
        setBotoesDesabilitados(["botao-emprestar"], false, "Enviando...");
    }
}

async function devolverOcupante(tipo, numero, prontuario) {
    const botoes = Array.from(document.querySelectorAll('[data-acao="devolver-ocupante"]'));
    botoes.forEach((botao) => {
        botao.disabled = true;
    });
    try {
        const data = await buscarJson("/devolver", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                tipo_armario: String(tipo || "").trim(),
                numero: String(numero || "").trim(),
                prontuario: String(prontuario || "").trim(),
                data: formatarDataParaBR(formatarDataDeInputHoje())
            })
        });
        exibirMensagem(data.mensagem || "Devolucao realizada com sucesso.", "sucesso", true);
        await atualizarTudo(true);
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    } finally {
        botoes.forEach((botao) => {
            botao.disabled = false;
        });
    }
}

async function cobrarPorEmail(tipo, numero, prontuario, botao = null) {
    if (!prontuario) {
        exibirMensagem("Informe o prontuario do aluno para enviar o email.", "erro", true);
        return;
    }

    const textoOriginal = botao?.textContent || "";
    if (botao) {
        botao.disabled = true;
        botao.textContent = "Enviando...";
    }

    try {
        const data = await enviarCobrancaEmail({
            tipoArmario: tipo,
            numero,
            prontuario,
        });
        exibirMensagem(data.mensagem || "Email enviado com sucesso.", "sucesso", true);
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    } finally {
        if (botao) {
            botao.disabled = false;
            botao.textContent = textoOriginal || "Cobrar por email";
        }
    }
}

function atualizarTipoConsulta() {
    const tipo = el("tipo-consulta").value;
    const seletor = el("tipo-consulta-armario");
    const campo = el("valor-consulta");
    seletor.disabled = tipo !== "numero";
    seletor.style.opacity = tipo === "numero" ? "1" : "0.65";
    campo.type = tipo === "numero" ? "number" : "text";
    campo.min = tipo === "numero" ? "1" : "";
    campo.placeholder = tipo === "numero"
        ? "Digite o numero do armario"
        : "Digite o prontuario";
    aplicarLimitesCampos();
}

function aplicarLimitesCampos() {
    const pares = [
        ["tipo-armario", "num"],
        ["tipo-dev", "num_dev"],
        ["tipo-consulta-armario", "valor-consulta"]
    ];
    pares.forEach(([tipoId, numeroId]) => {
        const campo = el(numeroId);
        if (!campo) return;
        if (campo.type !== "number" && numeroId !== "valor-consulta") return;
        if (numeroId === "valor-consulta" && el("tipo-consulta").value !== "numero") return;
        campo.min = "1";
        campo.max = String(limiteNumero(el(tipoId).value));
    });
    atualizarDicasMovimentacao();
    atualizarPreviewDevolucao();
}

async function consultar() {
    setBotoesDesabilitados(["botao-consultar"], true, "Buscando...");
    try {
        const params = new URLSearchParams({
            tipo: el("tipo-consulta").value,
            valor: el("valor-consulta").value.trim(),
            tipo_armario: el("tipo-consulta-armario").value
        });
        const data = await buscarJson(`/consultar?${params.toString()}`);
        if (!data.resultado) {
            el("resultado-consulta").innerHTML = '<div class="consulta-card"><p>Nenhuma ocupacao ativa encontrada para este criterio.</p></div>';
            exibirMensagem(data.mensagem || "Consulta concluida.");
            return;
        }
        const item = data.resultado;
        const ocupantes = ocupantesDoArmario(item);
        const ocupanteConsulta = item.ocupante_consulta || null;
        const subtitulo = ocupanteConsulta
            ? textoOuPadrao(ocupanteConsulta.nome, "Aluno nao informado")
            : ocupantes.length
                ? `${ocupantes.length} ${ocupantes.length === 1 ? "ocupante ativo" : "ocupantes ativos"}`
                : "Disponivel para novo emprestimo";
        el("resultado-consulta").innerHTML = `
            <div class="consulta-card">
                <div class="consulta-cabecalho">
                    <div class="armario-cabeca">
                        <div class="armario-numero">${escaparHtml(rotuloNumeroCurto(item))}</div>
                        <div class="armario-subtitulo">${subtitulo}</div>
                    </div>
                    <div class="armario-acoes">
                        ${renderizarIconeTipo(item.tipo)}
                        <span class="armario-status status-${item.status}">${rotuloStatus(item.status)}</span>
                    </div>
                </div>
                ${renderizarResumoOcupacao(item)}
                <div class="consulta-grade">
                    ${renderizarCampoConsulta("Tipo", rotuloTipo(item.tipo))}
                    ${renderizarCampoConsulta("Localizacao", obterLocalizacao(item.tipo, item.localizacao))}
                    ${renderizarCampoConsulta("Tamanho", rotuloTamanho(item.tamanho))}
                    ${renderizarCampoConsulta("Capacidade", textoCapacidade(item))}
                    ${renderizarCampoConsulta("Ocupacao", resumoOcupacao(item))}
                    ${renderizarCampoConsulta("Vagas", textoVagas(item))}
                    ${renderizarCampoConsulta("Status", rotuloStatus(item.status))}
                </div>
                ${
                    ocupantes.length
                        ? `<div class="preview-lista-ocupantes">${ocupantes.map((ocupante) => renderizarCardOcupante(item, ocupante, { destaque: !!ocupanteConsulta && ocupante.prontuario === ocupanteConsulta.prontuario })).join("")}</div>`
                        : `
                            <div class="armario-vazio">
                                <strong>Armario livre</strong>
                                <span class="armario-meta">Nao ha ocupantes ativos neste armario.</span>
                            </div>
                        `
                }
            </div>
        `;
        exibirMensagem("Consulta concluida.");
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    } finally {
        setBotoesDesabilitados(["botao-consultar"], false, "Buscando...");
    }
}

function alternarFiltrosHistorico() {
    const wrapper = el("filtros-historico");
    const botao = el("botao-filtros-historico");
    const estaOculto = wrapper.classList.toggle("oculto");
    botao.textContent = estaOculto ? "Mostrar filtros" : "Ocultar filtros";
}

async function listarAtrasados(silencioso = false) {
    try {
        const data = await buscarJson("/atrasados");
        if (!data.atrasados.length) {
            el("lista-atrasados").innerHTML = '<div class="consulta-card"><p>Tudo em dia.</p></div>';
        } else {
            const grupos = agruparPorTipo(data.atrasados);
            const blocos = ["livro", "convencional"].map((tipo) => {
                const itens = ordenarPorNumero(grupos[tipo] || []);
                if (!itens.length) return "";
                return `
                    <div class="lista-bloco">
                        <div class="lista-bloco-topo">
                            <div>
                                <h4>${escaparHtml(rotuloTipo(tipo))}</h4>
                                <p>${escaparHtml(obterLocalizacao(tipo, itens[0]?.localizacao))}</p>
                            </div>
                            <span class="mini-tag mini-tag--alerta">${itens.length} atraso(s)</span>
                        </div>
                        <div class="lista-registros">
                            ${itens.map((item) => renderizarRegistroAtrasado(item)).join("")}
                        </div>
                    </div>
                `;
            }).join("");
            el("lista-atrasados").innerHTML = `${renderizarResumoAtrasos(data.atrasados)}${blocos}`;
        }
        if (!silencioso) exibirMensagem("Lista de atrasados atualizada.");
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    }
}

async function carregarHistorico(silencioso = false) {
    try {
        const params = obterParametrosHistorico();
        const sufixo = params.toString() ? `?${params.toString()}` : "";
        const data = await buscarJson(`/historico${sufixo}`);
        const ativos = data.historico.filter((item) => item.status === "ativo").length;
        const devolvidos = data.historico.length - ativos;
        el("historico").innerHTML = data.historico.length ? `
            <div class="historico-resumo">
                <span class="historico-pill"><strong>${data.historico.length}</strong> registros</span>
                <span class="historico-pill"><strong>${ativos}</strong> ativos</span>
                <span class="historico-pill"><strong>${devolvidos}</strong> devolvidos</span>
            </div>
            <div class="tabela-wrap">
                <table class="tabela">
                    <thead>
                        <tr>
                            <th>Armario</th>
                            <th>Aluno</th>
                            <th>Datas</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.historico.map((item) => `
                            <tr class="${item.status}">
                                <td>
                                    <div class="tabela-celula">
                                        <div class="tabela-principal">${textoOuPadrao(item.identificacao)}</div>
                                        <div class="tabela-secundaria">${textoOuPadrao(item.tipo_rotulo)}</div>
                                        <div class="tabela-secundaria">${textoOuPadrao(item.localizacao)}</div>
                                        <div class="tabela-secundaria">Tamanho ${escaparHtml(rotuloTamanho(item.tamanho))}</div>
                                    </div>
                                </td>
                                <td>
                                    <div class="tabela-celula">
                                        <div class="tabela-principal">${textoOuPadrao(item.nome, "Aluno nao informado")}</div>
                                        <div class="tabela-secundaria">Email ${textoOuPadrao(item.email, "Nao informado")}</div>
                                        <div class="tabela-secundaria">Prontuario ${textoOuPadrao(item.prontuario)}</div>
                                        <div class="tabela-secundaria">Curso ${textoOuPadrao(item.curso, "Nao informado")}</div>
                                    </div>
                                </td>
                                <td>
                                    <div class="tabela-datas">
                                        <div class="tabela-data-item"><span>Retirada</span><strong>${textoOuPadrao(item.data_retirada)}</strong></div>
                                        <div class="tabela-data-item"><span>Prevista</span><strong>${textoOuPadrao(item.data_prevista)}</strong></div>
                                        <div class="tabela-data-item"><span>Devolucao</span><strong>${textoOuPadrao(item.data_devolucao)}</strong></div>
                                    </div>
                                </td>
                                <td>
                                    <div class="status-stack">
                                        <span class="status-tag ${item.status}">${rotuloStatusHistorico(item.status)}</span>
                                        <span class="tabela-secundaria">${item.status === "ativo" ? "Emprestimo em andamento" : "Fluxo encerrado"}</span>
                                    </div>
                                </td>
                            </tr>
                        `).join("")}
                    </tbody>
                </table>
            </div>
        ` : '<div class="consulta-card"><p>Nenhum registro encontrado para os filtros informados.</p></div>';
        if (!silencioso) exibirMensagem("Historico atualizado.");
    } catch (erro) {
        exibirMensagem(erro.message, "erro", true);
    }
}

function exportarHistoricoCsv() {
    const params = obterParametrosHistorico();
    const sufixo = params.toString() ? `?${params.toString()}` : "";
    window.open(`${API}/historico/csv${sufixo}`, "_blank");
    exibirMensagem("Exportacao CSV iniciada.", "sucesso", true);
}

function imprimirHistorico() {
    window.print();
    exibirMensagem("Janela de impressao aberta.");
}

function agendarHistoricoAutomatico() {
    clearTimeout(debounceHistorico);
    debounceHistorico = setTimeout(() => carregarHistorico(true), 450);
}

async function atualizarTudo(silencioso = false) {
    try {
        await carregarResumo();
        await listar();
        await listarAtrasados(true);
        await carregarHistorico(true);
        if (!silencioso) exibirMensagem("Painel atualizado.", "sucesso", true);
    } catch (erro) {
        exibirMensagem(erro.message || "Nao foi possivel atualizar o painel.", "erro", true);
    }
}

["hist-nome", "hist-prontuario"].forEach((id) => {
    el(id).addEventListener("input", agendarHistoricoAutomatico);
});

["hist-tipo", "hist-status", "hist-data-inicio", "hist-data-fim"].forEach((id) => {
    el(id).addEventListener("change", () => carregarHistorico(true));
});

["tipo-armario", "tipo-dev", "tipo-consulta-armario"].forEach((id) => {
    el(id).addEventListener("change", aplicarLimitesCampos);
});

function inicializarEventos() {
    el("tema-botao").addEventListener("click", alternarTema);
    el("botao-atualizar-painel").addEventListener("click", () => atualizarTudo());
    el("botao-abrir-mapa-atrasados").addEventListener("click", (event) => {
        abrirMapaComFiltro(event.currentTarget.dataset.mapaFiltro || "atrasado");
    });
    el("botao-atualizar-atrasados").addEventListener("click", () => listarAtrasados());
    el("botao-emprestar").addEventListener("click", emprestar);
    el("tipo-consulta").addEventListener("change", atualizarTipoConsulta);
    el("botao-consultar").addEventListener("click", consultar);
    el("botao-lista").addEventListener("click", alternarListaArmarios);
    el("filtro-armario").addEventListener("input", renderizarArmariosFiltrados);
    el("botao-filtros-historico").addEventListener("click", alternarFiltrosHistorico);
    el("botao-buscar-historico").addEventListener("click", () => carregarHistorico());
    el("botao-exportar-historico").addEventListener("click", exportarHistoricoCsv);
    el("botao-imprimir-historico").addEventListener("click", imprimirHistorico);

    document.querySelectorAll(".guia-botao").forEach((botao) => {
        botao.addEventListener("click", () => irParaArea(botao.dataset.area || "painel", botao.dataset.foco || ""));
    });

    document.querySelectorAll(".botao-atalho-curto").forEach((botao) => {
        botao.addEventListener("click", () => irParaArea(botao.dataset.irArea || "painel", botao.dataset.foco || ""));
    });

    document.querySelectorAll(".chip").forEach((chip) => {
        chip.addEventListener("click", () => definirFiltroRapido(chip.dataset.filtro || "todos"));
    });
}

el("num").addEventListener("input", atualizarPreviewEmprestimo);
el("num").addEventListener("change", atualizarPreviewEmprestimo);
el("num_dev").addEventListener("input", atualizarPreviewDevolucao);
el("num_dev").addEventListener("change", atualizarPreviewDevolucao);

document.addEventListener("click", async (event) => {
    const botaoCobranca = event.target.closest('[data-acao="cobrar-email"]');
    if (botaoCobranca) {
        await cobrarPorEmail(
            botaoCobranca.dataset.tipo,
            botaoCobranca.dataset.numero,
            botaoCobranca.dataset.prontuario,
            botaoCobranca,
        );
        return;
    }

    const botaoDevolucao = event.target.closest('[data-acao="devolver-ocupante"]');
    if (!botaoDevolucao) return;
    devolverOcupante(botaoDevolucao.dataset.tipo, botaoDevolucao.dataset.numero, botaoDevolucao.dataset.prontuario);
});

inicializarEventos();
el("data_prev").value = formatarDataDeInputHoje();
atualizarTipoConsulta();
aplicarLimitesCampos();
try {
    aplicarTemaSeguro(localStorage.getItem("tema_armarios") || "claro");
} catch (erro) {
    aplicarTemaSeguro("claro");
}
try {
    irParaArea(localStorage.getItem("area_armarios") || "painel");
} catch (erro) {
    irParaArea("painel");
}
atualizarTudo(true);

