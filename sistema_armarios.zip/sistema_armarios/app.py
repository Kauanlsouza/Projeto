import csv
import io
import json
import os
import smtplib
import atexit
from datetime import datetime, timedelta
from email.message import EmailMessage
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from database import (
    atualizar_emprestimo_ativo,
    consultar_armario_flexivel,
    contar_armarios_por_status,
    criar_armarios,
    criar_banco,
    devolver_armario,
    emprestar_armario,
    listar_armarios_detalhados,
    listar_armarios_livres,
    listar_atrasados,
    listar_historico_emprestimos,
    normalizar_tipo_armario,
    validar_numero_armario,
)


BASE_DIR = Path(__file__).resolve().parent
INDEX_FILE = BASE_DIR / "index.html"
PAGE_FILES = {
    "inicio": INDEX_FILE,
    "movimentacoes": BASE_DIR / "movimentacoes.html",
    "consulta": BASE_DIR / "consulta.html",
    "disponibilidade": BASE_DIR / "disponibilidade.html",
    "historico": BASE_DIR / "historico.html",
    "configuracoes": BASE_DIR / "configuracoes.html",
}
CONFIG_FILE = BASE_DIR / "configuracoes.json"
LOCK_FILE = BASE_DIR / ".app.lock"
HOST = "127.0.0.1"
PORT = 5000
DATE_FORMAT = "%d/%m/%Y"
DATE_INPUT_FORMAT = "%Y-%m-%d"
HISTORICO_ORDENACOES_VALIDAS = {
    "armario",
    "tipo",
    "localizacao",
    "tamanho",
    "participante_1",
    "participante_2",
    "participante_3",
    "retirada",
    "prevista",
    "devolucao",
    "status",
}
CONFIGURACOES_PADRAO = {
    "email_assunto": "Devolucao em atraso - {armario}",
    "email_corpo": (
        "Ola {nome},\n\n"
        "identificamos que o {armario} esta com devolucao prevista para {prazo}.\n"
        "Localizacao: {localizacao}.\n\n"
        "Pedimos a regularizacao o quanto antes.\n\n"
        "Equipe de armarios"
    ),
}
SERVER_LOCK_HANDLE = None
PAGE_ROUTES = {
    "/": {"page": "inicio", "title": "Sistema de Armarios"},
    "/index.html": {"page": "inicio", "title": "Sistema de Armarios"},
    "/movimentacoes.html": {"page": "movimentacoes", "title": "Movimentacoes | Sistema de Armarios"},
    "/consulta.html": {"page": "consulta", "title": "Consulta | Sistema de Armarios"},
    "/disponibilidade.html": {"page": "disponibilidade", "title": "Disponibilidade | Sistema de Armarios"},
    "/historico.html": {"page": "historico", "title": "Historico | Sistema de Armarios"},
    "/configuracoes.html": {"page": "configuracoes", "title": "Configuracoes | Sistema de Armarios"},
}

try:
    import msvcrt
except ImportError:  # pragma: no cover - ambiente Windows no uso real
    msvcrt = None


def carregar_dotenv(caminho):
    if not caminho.is_file():
        return

    for linha in caminho.read_text(encoding="utf-8").splitlines():
        conteudo = linha.strip()
        if not conteudo or conteudo.startswith("#") or "=" not in conteudo:
            continue

        chave, valor = conteudo.split("=", 1)
        chave = chave.strip()
        valor = valor.strip().strip('"').strip("'")
        if chave and chave not in os.environ:
            os.environ[chave] = valor


carregar_dotenv(BASE_DIR / ".env")


def adquirir_bloqueio_servidor():
    global SERVER_LOCK_HANDLE
    if msvcrt is None:
        return

    lock = open(LOCK_FILE, "a+b")
    try:
        lock.seek(0)
        if not lock.read(1):
            lock.seek(0)
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    except OSError as exc:
        lock.close()
        raise RuntimeError(
            "Ja existe uma instancia do app.py em execucao. Feche a anterior antes de iniciar outra."
        ) from exc

    lock.seek(0)
    lock.truncate()
    lock.write(str(os.getpid()).encode("ascii"))
    lock.flush()
    SERVER_LOCK_HANDLE = lock


def liberar_bloqueio_servidor():
    global SERVER_LOCK_HANDLE
    if SERVER_LOCK_HANDLE is None or msvcrt is None:
        return

    try:
        SERVER_LOCK_HANDLE.seek(0)
        msvcrt.locking(SERVER_LOCK_HANDLE.fileno(), msvcrt.LK_UNLCK, 1)
    except OSError:
        pass
    try:
        SERVER_LOCK_HANDLE.close()
    finally:
        SERVER_LOCK_HANDLE = None


def renderizar_index(page_key="inicio", page_title="Sistema de Armarios"):
    html = INDEX_FILE.read_text(encoding="utf-8")
    html = html.replace("<title>Sistema de Armarios</title>", f"<title>{page_title}</title>", 1)
    payload = (
        "<script>"
        f"window.APP_PAGE = {json.dumps(page_key, ensure_ascii=False)};"
        "</script>"
    )
    return html.replace("</head>", f"{payload}\n</head>", 1).encode("utf-8")


def resolver_pagina_por_caminho(caminho):
    page_config = PAGE_ROUTES.get(caminho)
    if page_config:
        return page_config

    if caminho.endswith(".html"):
        nome = Path(caminho).name.lower()
        page_key = nome[:-5] if nome.endswith(".html") else nome
        if page_key in PAGE_FILES:
            return {"page": page_key, "title": f"{page_key.title()} | Sistema de Armarios"}

    return None


def hoje():
    return datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)


def json_response(handler, status, payload):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def resposta_ok(handler, payload, status=HTTPStatus.OK):
    json_response(handler, status, {"ok": True, **payload})


def resposta_erro(handler, mensagem, status=HTTPStatus.BAD_REQUEST):
    json_response(handler, status, {"ok": False, "mensagem": mensagem})


def texto_limpo(valor):
    if valor is None or isinstance(valor, bool):
        return ""
    return str(valor).strip()


def normalizar_data(data_str):
    valor = texto_limpo(data_str)
    if not valor:
        return ""

    for formato in (DATE_FORMAT, DATE_INPUT_FORMAT):
        try:
            return datetime.strptime(valor, formato).strftime(DATE_FORMAT)
        except ValueError:
            continue

    raise ValueError("Data invalida. Use DD/MM/AAAA.")


def validar_data_prevista(data_prevista):
    dt_prevista = datetime.strptime(data_prevista, DATE_FORMAT)
    if dt_prevista < hoje():
        raise ValueError("A data prevista nao pode ser no passado.")


def validar_data_devolucao(data_devolucao):
    dt_devolucao = datetime.strptime(data_devolucao, DATE_FORMAT)
    limite = hoje() + timedelta(days=1)
    if dt_devolucao > limite:
        raise ValueError("A data de devolucao nao pode ser futura.")


def validar_intervalo_datas(data_inicio, data_fim):
    if not data_inicio or not data_fim:
        return

    if datetime.strptime(data_inicio, DATE_FORMAT) > datetime.strptime(data_fim, DATE_FORMAT):
        raise ValueError("A data inicial nao pode ser maior que a data final.")


def esta_atrasado(data_prevista):
    if not data_prevista:
        return False

    try:
        return datetime.strptime(data_prevista, DATE_FORMAT) < hoje()
    except ValueError:
        return False


def classificar_vencimento(data_prevista):
    if not data_prevista:
        return "sem_prazo"

    try:
        data = datetime.strptime(data_prevista, DATE_FORMAT)
    except ValueError:
        return "sem_prazo"

    diferenca = (data - hoje()).days
    if diferenca < 0:
        return "atrasado"
    if diferenca == 0:
        return "vence_hoje"
    if diferenca == 1:
        return "vence_amanha"
    return "no_prazo"


def parse_numero(valor, mensagem="Numero invalido."):
    if isinstance(valor, bool):
        raise ValueError(mensagem)
    try:
        return int(valor)
    except (TypeError, ValueError) as exc:
        raise ValueError(mensagem) from exc


def parse_bool(valor):
    if isinstance(valor, bool):
        return valor
    if isinstance(valor, (int, float)):
        return bool(valor)
    texto = str(valor or "").strip().lower()
    return texto in {"1", "true", "yes", "on", "sim"}


def parse_tipo_armario(valor):
    try:
        return normalizar_tipo_armario(valor)
    except ValueError as exc:
        raise ValueError(str(exc)) from exc


def validar_numero_por_tipo(tipo_armario, numero):
    try:
        return validar_numero_armario(tipo_armario, numero)
    except ValueError as exc:
        raise ValueError(str(exc)) from exc


def campos_faltando(dados, obrigatorios):
    return [campo for campo in obrigatorios if not texto_limpo(dados.get(campo, ""))]


def extrair_participantes(dados):
    participantes = dados.get("participantes")
    if isinstance(participantes, list):
        return participantes

    if any(texto_limpo(dados.get(campo, "")) for campo in ("nome", "email", "prontuario", "curso")):
        return [
            {
                "nome": dados.get("nome", ""),
                "email": dados.get("email", ""),
                "prontuario": dados.get("prontuario", ""),
                "curso": dados.get("curso", ""),
            }
        ]

    return []


def ler_bool_env(nome, padrao=False):
    valor = os.getenv(nome)
    if valor is None:
        return padrao
    return str(valor).strip().lower() in {"1", "true", "yes", "on", "sim"}


def smtp_configurado():
    return bool(str(os.getenv("SMTP_HOST", "")).strip() and str(os.getenv("SMTP_FROM_EMAIL", "")).strip())


def _normalizar_configuracoes_payload(payload):
    payload = payload or {}
    assunto = str(payload.get("email_assunto", "")).strip() or CONFIGURACOES_PADRAO["email_assunto"]
    corpo = str(payload.get("email_corpo", "")).strip() or CONFIGURACOES_PADRAO["email_corpo"]
    return {
        "email_assunto": assunto,
        "email_corpo": corpo,
    }


def carregar_configuracoes():
    if not CONFIG_FILE.is_file():
        return dict(CONFIGURACOES_PADRAO)

    try:
        bruto = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return dict(CONFIGURACOES_PADRAO)

    if not isinstance(bruto, dict):
        return dict(CONFIGURACOES_PADRAO)

    return _normalizar_configuracoes_payload(bruto)


def salvar_configuracoes(payload):
    configuracoes = _normalizar_configuracoes_payload(payload)
    CONFIG_FILE.write_text(
        json.dumps(configuracoes, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return configuracoes


def csv_response(handler, filename, rows):
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    for row in rows:
        writer.writerow(row)
    body = buffer.getvalue().encode("utf-8-sig")
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", "text/csv; charset=utf-8")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def obter_config_email():
    host = str(os.getenv("SMTP_HOST", "")).strip()
    from_email = str(os.getenv("SMTP_FROM_EMAIL", "")).strip()
    from_name = str(os.getenv("SMTP_FROM_NAME", "")).strip() or "Sistema de Armarios"
    username = str(os.getenv("SMTP_USERNAME", "")).strip()
    password = os.getenv("SMTP_PASSWORD", "")
    port_raw = str(os.getenv("SMTP_PORT", "587")).strip()
    use_ssl = ler_bool_env("SMTP_USE_SSL", False)
    use_tls = ler_bool_env("SMTP_USE_TLS", not use_ssl)

    if not host or not from_email:
        raise ValueError(
            "Envio de email nao configurado. Defina SMTP_HOST e SMTP_FROM_EMAIL nas variaveis de ambiente."
        )

    try:
        port = int(port_raw)
    except ValueError as exc:
        raise ValueError("SMTP_PORT invalido.") from exc

    return {
        "host": host,
        "port": port,
        "username": username,
        "password": password,
        "from_email": from_email,
        "from_name": from_name,
        "use_ssl": use_ssl,
        "use_tls": use_tls,
    }


def enviar_email(destinatario, assunto, corpo):
    config = obter_config_email()
    mensagem = EmailMessage()
    mensagem["Subject"] = assunto
    mensagem["From"] = f'{config["from_name"]} <{config["from_email"]}>'
    mensagem["To"] = destinatario
    mensagem.set_content(corpo)

    smtp_cls = smtplib.SMTP_SSL if config["use_ssl"] else smtplib.SMTP
    with smtp_cls(config["host"], config["port"], timeout=20) as servidor:
        servidor.ehlo()
        if not config["use_ssl"] and config["use_tls"]:
            servidor.starttls()
            servidor.ehlo()
        if config["username"]:
            servidor.login(config["username"], config["password"])
        servidor.send_message(mensagem)


def renderizar_template_email(template, participante, armario):
    valores = {
        "{nome}": participante.get("nome") or "responsavel",
        "{armario}": armario.get("identificacao") or "armario",
        "{prazo}": armario.get("data_prevista") or "-",
        "{localizacao}": armario.get("localizacao") or "-",
        "{tipo}": armario.get("tipo_rotulo") or "armario",
        "{curso}": participante.get("curso") or "-",
        "{email}": participante.get("email") or "-",
    }
    conteudo = str(template or "")
    for marcador, valor in valores.items():
        conteudo = conteudo.replace(marcador, str(valor))
    return conteudo


def enviar_cobranca_armario(armario, assunto_template="", corpo_template=""):
    participantes = [
        participante
        for participante in (armario.get("participantes") or [])
        if str(participante.get("email", "")).strip()
    ]
    if not participantes:
        raise ValueError("Nao ha emails cadastrados para este armario.")

    configuracoes = carregar_configuracoes()
    assunto_base = str(assunto_template or configuracoes["email_assunto"]).strip()
    corpo_base = str(corpo_template or configuracoes["email_corpo"]).strip()
    enviados = 0

    for participante in participantes:
        assunto = renderizar_template_email(assunto_base, participante, armario)
        corpo = renderizar_template_email(corpo_base, participante, armario)
        enviar_email(participante["email"], assunto, corpo)
        enviados += 1

    return enviados


def enriquecer_armario(item):
    return {
        **item,
        "atrasado": esta_atrasado(item.get("data_prevista")),
        "vencimento": classificar_vencimento(item.get("data_prevista")),
    }


def formatar_consulta(resultado):
    if not resultado:
        return None
    return enriquecer_armario(resultado)


def normalizar_inteiro_param(valor, padrao, minimo=1, maximo=500):
    try:
        numero = int(valor)
    except (TypeError, ValueError):
        return padrao
    return max(minimo, min(numero, maximo))


def normalizar_ordenacao_historico(valor):
    campo = str(valor or "").strip().lower()
    return campo if campo in HISTORICO_ORDENACOES_VALIDAS else "retirada"


def normalizar_direcao_historico(valor):
    return "asc" if str(valor or "").strip().lower() == "asc" else "desc"


def _valor_data_ordenacao(valor, vazio_ao_final=True):
    if not valor:
        return (1 if vazio_ao_final else -1, datetime.max)
    try:
        return (0, datetime.strptime(valor, DATE_FORMAT))
    except ValueError:
        return (1 if vazio_ao_final else -1, datetime.max)


def _valor_texto_ordenacao(valor):
    return str(valor or "").strip().lower()


def _participante_por_indice(item, indice):
    participantes = item.get("participantes") or []
    return participantes[indice] if indice < len(participantes) else {}


def _ordem_tipo_item(item):
    return 0


def _chave_ordenacao_historico(item, campo):
    if campo == "armario":
        return (_ordem_tipo_item(item), int(item.get("numero") or 0))
    if campo == "tipo":
        return (_ordem_tipo_item(item), int(item.get("numero") or 0))
    if campo == "localizacao":
        return (_valor_texto_ordenacao(item.get("localizacao")), int(item.get("numero") or 0))
    if campo == "tamanho":
        return (_valor_texto_ordenacao(item.get("tamanho")), int(item.get("numero") or 0))
    if campo == "participante_1":
        participante = _participante_por_indice(item, 0)
        return _valor_texto_ordenacao(participante.get("nome") or item.get("nome"))
    if campo == "participante_2":
        return _valor_texto_ordenacao(_participante_por_indice(item, 1).get("nome"))
    if campo == "participante_3":
        return _valor_texto_ordenacao(_participante_por_indice(item, 2).get("nome"))
    if campo == "prevista":
        return _valor_data_ordenacao(item.get("data_prevista"))
    if campo == "devolucao":
        return _valor_data_ordenacao(item.get("data_devolucao"))
    if campo == "status":
        return (_valor_texto_ordenacao(item.get("status")), _valor_data_ordenacao(item.get("data_retirada")))
    return _valor_data_ordenacao(item.get("data_retirada"))


def preparar_historico(params, paginar=True):
    try:
        data_inicio_raw = params.get("data_inicio", [""])[0]
        data_fim_raw = params.get("data_fim", [""])[0]
        data_inicio = normalizar_data(data_inicio_raw) if data_inicio_raw else ""
        data_fim = normalizar_data(data_fim_raw) if data_fim_raw else ""
        validar_intervalo_datas(data_inicio, data_fim)
        tipo_armario = params.get("tipo_armario", [""])[0].strip()
        if tipo_armario:
            tipo_armario = parse_tipo_armario(tipo_armario)
    except ValueError as exc:
        raise ValueError(str(exc)) from exc

    ordenacao = normalizar_ordenacao_historico(params.get("ordenar_por", ["retirada"])[0])
    direcao = normalizar_direcao_historico(params.get("direcao", ["desc"])[0])
    por_pagina = normalizar_inteiro_param(params.get("por_pagina", ["10"])[0], 10, minimo=1, maximo=100)
    pagina = normalizar_inteiro_param(params.get("pagina", ["1"])[0], 1, minimo=1, maximo=9999)

    historico = listar_historico_emprestimos(
        nome=params.get("nome", [""])[0].strip(),
        prontuario=params.get("prontuario", [""])[0].strip(),
        status=params.get("status", [""])[0].strip(),
        data_inicio=data_inicio,
        data_fim=data_fim,
        tipo_armario=tipo_armario,
    )
    historico_ordenado = sorted(
        historico,
        key=lambda item: _chave_ordenacao_historico(item, ordenacao),
        reverse=direcao == "desc",
    )
    resumo = {
        "total": len(historico_ordenado),
        "ativos": sum(1 for item in historico_ordenado if item.get("status") == "ativo"),
        "devolvidos": sum(1 for item in historico_ordenado if item.get("status") == "devolvido"),
        "atrasados": sum(
            1
            for item in historico_ordenado
            if item.get("status") == "ativo" and esta_atrasado(item.get("data_prevista"))
        ),
    }

    total_itens = len(historico_ordenado)
    total_paginas = max(1, (total_itens + por_pagina - 1) // por_pagina)
    pagina = min(pagina, total_paginas)

    if not paginar:
        return {
            "historico": historico_ordenado,
            "resumo": resumo,
            "paginacao": {
                "pagina": 1,
                "por_pagina": total_itens or por_pagina,
                "total_itens": total_itens,
                "total_paginas": 1,
            },
            "ordenacao": {"campo": ordenacao, "direcao": direcao},
        }

    inicio = (pagina - 1) * por_pagina
    fim = inicio + por_pagina
    return {
        "historico": historico_ordenado[inicio:fim],
        "resumo": resumo,
        "paginacao": {
            "pagina": pagina,
            "por_pagina": por_pagina,
            "total_itens": total_itens,
            "total_paginas": total_paginas,
        },
        "ordenacao": {"campo": ordenacao, "direcao": direcao},
    }


def montar_agenda_devolucoes():
    agenda = {
        "vence_hoje": [],
        "vence_amanha": [],
        "proximos_7_dias": [],
    }
    base = hoje()
    limite = base + timedelta(days=7)

    for item in listar_armarios_detalhados():
        if item.get("status") != "ocupado" or not item.get("data_prevista"):
            continue
        try:
            data_prevista = datetime.strptime(item["data_prevista"], DATE_FORMAT)
        except ValueError:
            continue
        if data_prevista < base or data_prevista > limite:
            continue

        item_enriquecido = enriquecer_armario(item)
        diferenca = (data_prevista - base).days
        if diferenca == 0:
            agenda["vence_hoje"].append(item_enriquecido)
        elif diferenca == 1:
            agenda["vence_amanha"].append(item_enriquecido)
        else:
            agenda["proximos_7_dias"].append(item_enriquecido)

    for chave in agenda:
        agenda[chave].sort(
            key=lambda item: (
                datetime.strptime(item["data_prevista"], DATE_FORMAT),
                int(item.get("numero") or 0),
            )
        )

    return agenda


class ArmariosHandler(BaseHTTPRequestHandler):
    def _rota_normalizada(self):
        caminho = urlparse(self.path).path.strip()
        if not caminho:
            return "/"
        if caminho != "/" and caminho.endswith("/"):
            caminho = caminho.rstrip("/")
        if caminho == "/api":
            return "/"
        if caminho.startswith("/api/"):
            return caminho[4:]
        return caminho

    def do_OPTIONS(self):
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self):
        rota = urlparse(self.path)
        caminho = self._rota_normalizada()
        params = parse_qs(rota.query)

        page_config = PAGE_ROUTES.get(caminho)
        if page_config:
            self._servir_index(page_config["page"], page_config["title"])
            return

        if caminho == "/resumo":
            resumo = contar_armarios_por_status()
            agenda = montar_agenda_devolucoes()
            resumo["atrasados"] = len(listar_atrasados())
            resumo["vence_hoje"] = len(agenda["vence_hoje"])
            resumo["vence_amanha"] = len(agenda["vence_amanha"])
            resumo["proximos_7_dias"] = len(agenda["proximos_7_dias"])
            total_armarios = resumo["convencional_total"]
            resumo["ocupacao_percentual"] = round((resumo["ocupado"] / total_armarios) * 100, 1) if total_armarios else 0
            resposta_ok(self, {"resumo": resumo, "agenda": agenda})
            return

        if caminho == "/armarios":
            armarios = [enriquecer_armario(item) for item in listar_armarios_detalhados()]
            resposta_ok(self, {"armarios": armarios})
            return

        if caminho == "/agenda-devolucoes":
            resposta_ok(self, {"agenda": montar_agenda_devolucoes()})
            return

        if caminho == "/armarios/livres":
            tipo_armario = params.get("tipo_armario", [""])[0].strip()
            livres = listar_armarios_livres(tipo_armario=tipo_armario)
            resposta_ok(self, {"armarios": [enriquecer_armario(item) for item in livres]})
            return

        if caminho == "/atrasados":
            resposta_ok(self, {"atrasados": [enriquecer_armario(item) for item in listar_atrasados()]})
            return

        if caminho == "/consultar":
            self._consultar(params)
            return

        if caminho == "/historico":
            self._historico(params)
            return

        if caminho == "/historico/csv":
            self._historico_csv(params)
            return

        if caminho == "/configuracoes":
            self._configuracoes()
            return

        resposta_erro(self, "Rota nao encontrada.", HTTPStatus.NOT_FOUND)

    def do_POST(self):
        caminho = self._rota_normalizada()

        if caminho == "/emprestar":
            self._emprestar()
            return

        if caminho == "/devolver":
            self._devolver()
            return

        if caminho == "/emprestimo/atualizar":
            self._atualizar_emprestimo()
            return

        if caminho == "/configuracoes":
            self._salvar_configuracoes()
            return

        if caminho == "/cobrar-email":
            self._cobrar_email()
            return

        resposta_erro(self, "Rota nao encontrada.", HTTPStatus.NOT_FOUND)

    def _servir_index(self, page_key="inicio", page_title="Sistema de Armarios"):
        content = renderizar_index(page_key, page_title)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _consultar(self, params):
        tipo_consulta = params.get("tipo", ["numero"])[0]
        valor = params.get("valor", [""])[0].strip()

        if not valor:
            resposta_erro(self, "Informe um valor para consulta.")
            return

        if tipo_consulta == "numero":
            try:
                tipo_armario = parse_tipo_armario(params.get("tipo_armario", [""])[0].strip())
                numero = validar_numero_por_tipo(tipo_armario, parse_numero(valor))
                resultado = consultar_armario_flexivel(numero, por_prontuario=False, tipo_armario=tipo_armario)
            except ValueError as exc:
                resposta_erro(self, str(exc))
                return
        elif tipo_consulta == "prontuario":
            resultado = consultar_armario_flexivel(valor, por_prontuario=True)
        else:
            resposta_erro(self, "Tipo de consulta invalido.")
            return

        if not resultado:
            resposta_ok(self, {"resultado": None, "mensagem": "Nenhuma ocupacao ativa encontrada."})
            return

        resposta_ok(self, {"resultado": formatar_consulta(resultado)})

    def _historico(self, params):
        try:
            historico_payload = preparar_historico(params, paginar=True)
        except ValueError as exc:
            resposta_erro(self, str(exc))
            return

        resposta_ok(self, historico_payload)

    def _historico_csv(self, params):
        try:
            historico_payload = preparar_historico(params, paginar=False)
        except ValueError as exc:
            resposta_erro(self, str(exc))
            return

        historico = historico_payload["historico"]
        rows = [
            [
                "Armario",
                "Tipo",
                "Numero",
                "Localizacao",
                "Tamanho",
                "Participante 1 Nome",
                "Participante 1 Email",
                "Participante 1 Prontuario",
                "Participante 1 Curso",
                "Participante 2 Nome",
                "Participante 2 Email",
                "Participante 2 Prontuario",
                "Participante 2 Curso",
                "Participante 3 Nome",
                "Participante 3 Email",
                "Participante 3 Prontuario",
                "Participante 3 Curso",
                "Retirada",
                "Prevista",
                "Devolucao",
                "Status",
            ]
        ]
        for item in historico:
            participantes = list(item.get("participantes") or [])[:3]
            while len(participantes) < 3:
                participantes.append({})
            rows.append(
                [
                    item["identificacao"],
                    item["tipo_rotulo"],
                    item["numero"],
                    item["localizacao"],
                    "Grande" if item["tamanho"] == "grande" else "Padrao",
                    participantes[0].get("nome", ""),
                    participantes[0].get("email", ""),
                    participantes[0].get("prontuario", ""),
                    participantes[0].get("curso", ""),
                    participantes[1].get("nome", ""),
                    participantes[1].get("email", ""),
                    participantes[1].get("prontuario", ""),
                    participantes[1].get("curso", ""),
                    participantes[2].get("nome", ""),
                    participantes[2].get("email", ""),
                    participantes[2].get("prontuario", ""),
                    participantes[2].get("curso", ""),
                    item["data_retirada"],
                    item["data_prevista"],
                    item["data_devolucao"] or "",
                    item["status"],
                ]
            )
        csv_response(self, "historico_armarios.csv", rows)

    def _configuracoes(self):
        resposta_ok(
            self,
            {
                "configuracoes": carregar_configuracoes(),
                "smtp_configurado": smtp_configurado(),
            },
        )

    def _salvar_configuracoes(self):
        dados = self._read_json()
        if dados is None:
            return

        try:
            configuracoes = salvar_configuracoes(dados)
        except OSError:
            resposta_erro(self, "Nao foi possivel salvar as configuracoes.", HTTPStatus.INTERNAL_SERVER_ERROR)
            return

        resposta_ok(
            self,
            {
                "mensagem": "Configuracoes salvas com sucesso.",
                "configuracoes": configuracoes,
                "smtp_configurado": smtp_configurado(),
            },
        )

    def _emprestar(self):
        dados = self._read_json()
        if dados is None:
            return

        faltando = campos_faltando(dados, ["tipo_armario", "numero", "data_prevista"])
        if faltando:
            resposta_erro(self, f"Preencha os campos: {', '.join(faltando)}.")
            return

        participantes = extrair_participantes(dados)
        try:
            tipo_armario = parse_tipo_armario(dados["tipo_armario"])
            numero = validar_numero_por_tipo(tipo_armario, parse_numero(dados["numero"]))
            data_retirada = normalizar_data(dados.get("data_retirada") or datetime.now().strftime(DATE_FORMAT))
            data_prevista = normalizar_data(dados["data_prevista"])
            cadeado_proprio = parse_bool(dados.get("cadeado_proprio"))
            validar_data_prevista(data_prevista)
        except ValueError as exc:
            resposta_erro(self, str(exc) or "Dados invalidos.")
            return

        try:
            ok, mensagem = emprestar_armario(
                tipo_armario,
                numero,
                participantes,
                data_retirada,
                data_prevista,
                cadeado_proprio,
            )
        except ValueError as exc:
            resposta_erro(self, str(exc) or "Dados invalidos.")
            return
        resposta = resposta_ok if ok else resposta_erro
        status = HTTPStatus.OK if ok else HTTPStatus.BAD_REQUEST
        resposta(self, {"mensagem": mensagem} if ok else mensagem, status)

    def _devolver(self):
        dados = self._read_json()
        if dados is None:
            return

        try:
            tipo_armario = parse_tipo_armario(dados.get("tipo_armario", ""))
            numero = validar_numero_por_tipo(tipo_armario, parse_numero(dados.get("numero", "")))
            data_devolucao = normalizar_data(dados.get("data") or datetime.now().strftime(DATE_FORMAT))
            validar_data_devolucao(data_devolucao)
        except ValueError as exc:
            resposta_erro(self, str(exc) or "Dados invalidos.")
            return

        ok, mensagem = devolver_armario(tipo_armario, numero, data_devolucao)
        resposta = resposta_ok if ok else resposta_erro
        status = HTTPStatus.OK if ok else HTTPStatus.BAD_REQUEST
        resposta(self, {"mensagem": mensagem} if ok else mensagem, status)

    def _atualizar_emprestimo(self):
        dados = self._read_json()
        if dados is None:
            return

        faltando = campos_faltando(dados, ["tipo_armario", "numero", "data_prevista"])
        if faltando:
            resposta_erro(self, f"Preencha os campos: {', '.join(faltando)}.")
            return

        participantes = extrair_participantes(dados)
        try:
            tipo_armario = parse_tipo_armario(dados["tipo_armario"])
            numero = validar_numero_por_tipo(tipo_armario, parse_numero(dados["numero"]))
            data_prevista = normalizar_data(dados["data_prevista"])
            cadeado_proprio = parse_bool(dados.get("cadeado_proprio"))
            validar_data_prevista(data_prevista)
        except ValueError as exc:
            resposta_erro(self, str(exc) or "Dados invalidos.")
            return

        try:
            ok, mensagem = atualizar_emprestimo_ativo(
                tipo_armario,
                numero,
                participantes,
                data_prevista,
                cadeado_proprio,
            )
        except ValueError as exc:
            resposta_erro(self, str(exc) or "Dados invalidos.")
            return
        resposta = resposta_ok if ok else resposta_erro
        status = HTTPStatus.OK if ok else HTTPStatus.BAD_REQUEST
        resposta(self, {"mensagem": mensagem} if ok else mensagem, status)

    def _cobrar_email(self):
        dados = self._read_json()
        if dados is None:
            return

        try:
            tipo_armario = parse_tipo_armario(dados.get("tipo_armario", ""))
            numero = validar_numero_por_tipo(tipo_armario, parse_numero(dados.get("numero", "")))
            armario = consultar_armario_flexivel(numero, por_prontuario=False, tipo_armario=tipo_armario)
            if not armario or armario.get("status") != "ocupado":
                resposta_erro(self, "Nao foi encontrado emprestimo ativo para este armario.")
                return
            if not esta_atrasado(armario.get("data_prevista")):
                resposta_erro(self, "O email de cobranca so pode ser enviado para armarios atrasados.")
                return

            enviados = enviar_cobranca_armario(
                armario,
                assunto_template=str(dados.get("assunto", "")).strip(),
                corpo_template=str(dados.get("mensagem", "")).strip(),
            )
        except ValueError as exc:
            resposta_erro(self, str(exc), HTTPStatus.BAD_REQUEST)
            return
        except OSError:
            resposta_erro(self, "Nao foi possivel salvar ou acessar as configuracoes.", HTTPStatus.INTERNAL_SERVER_ERROR)
            return
        except (smtplib.SMTPException, ConnectionError):
            resposta_erro(self, "Nao foi possivel enviar o email agora.", HTTPStatus.BAD_GATEWAY)
            return

        resposta_ok(
            self,
            {"mensagem": f"Cobranca enviada automaticamente para {enviados} responsavel(is)."},
        )

    def _read_json(self):
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            resposta_erro(self, "Cabecalho Content-Length invalido.")
            return None

        if content_length < 0:
            resposta_erro(self, "Cabecalho Content-Length invalido.")
            return None

        try:
            raw_body = self.rfile.read(content_length).decode("utf-8") if content_length else "{}"
        except UnicodeDecodeError:
            resposta_erro(self, "O corpo da requisicao precisa estar em UTF-8.")
            return None

        try:
            dados = json.loads(raw_body)
        except json.JSONDecodeError:
            resposta_erro(self, "JSON invalido.")
            return None

        if not isinstance(dados, dict):
            resposta_erro(self, "O corpo da requisicao deve ser um objeto JSON.")
            return None

        return dados

    def log_message(self, format, *args):
        return


def main():
    adquirir_bloqueio_servidor()
    atexit.register(liberar_bloqueio_servidor)
    criar_banco()
    criar_armarios()
    server = ThreadingHTTPServer((HOST, PORT), ArmariosHandler)
    print(f"Servidor rodando em http://{HOST}:{PORT} (PID {os.getpid()})")
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as exc:
        print(f"[ERRO] {exc}")
